# Banking System Website

A simple banking system converted from a Python console program into a web application using Flask.

## Features

- Create a bank account
- Customer login
- Deposit money
- Withdraw money
- View account details
- Manager login
- Manager account overview
- HTML/CSS web interface

## Technologies

- Python
- Flask
- HTML
- CSS

## How to Run

1. Install Python.
2. Open a terminal in this project folder.
3. Install Flask:

```bash
pip install -r requirements.txt
```

4. Start the website:

```bash
python app.py
```

5. Open this address in your browser:

```text
http://127.0.0.1:5000
```

## Manager Code

For this educational project, the manager code is:

```text
234
```

## Important

This is an educational project. Account data is stored in memory and is lost when the program stops. Passwords are not stored using production-grade security. Do not use this project as a real banking service.
