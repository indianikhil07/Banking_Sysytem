from flask import Flask, render_template, request, redirect, url_for, session, flash
import time

app = Flask(__name__)
app.secret_key = "banking-system-demo-secret-key"


class Bank:
    def __init__(self):
        self.register = {}

    def registration(self, name, password, opening_balance):
        if name in self.register:
            return False, "Account already exists."

        self.register[name] = {
            "password": password,
            "balance": float(opening_balance)
        }
        return True, "Account opened successfully."

    def login(self, name, password):
        return (
            name in self.register
            and self.register[name]["password"] == password
        )

    def deposit(self, name, amount):
        if name not in self.register:
            return False, "Account not found."

        if amount <= 0:
            return False, "Enter a valid amount."

        self.register[name]["balance"] += amount
        return True, "Amount deposited successfully."

    def withdrawl(self, name, amount):
        if name not in self.register:
            return False, "Account not found."

        if amount <= 0:
            return False, "Enter a valid amount."

        if self.register[name]["balance"] < amount:
            return False, "You do not have sufficient balance."

        self.register[name]["balance"] -= amount
        return True, "Amount withdrawn successfully."

    def account_details(self, name):
        if name in self.register:
            return self.register[name]
        return None

    def total_account(self):
        return len(self.register)

    def display_whole(self):
        return {
            name: data["balance"]
            for name, data in self.register.items()
        }


manager_code = 234
bank = Bank()


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form["name"].strip()
        password = request.form["password"]
        opening_balance = request.form["opening_balance"]

        if not name or not password or not opening_balance:
            flash("Please fill in all fields.", "error")
            return redirect(url_for("register"))

        try:
            opening_balance = float(opening_balance)
        except ValueError:
            flash("Opening balance must be a number.", "error")
            return redirect(url_for("register"))

        if opening_balance < 0:
            flash("Opening balance cannot be negative.", "error")
            return redirect(url_for("register"))

        success, message = bank.registration(
            name, password, opening_balance
        )

        flash(message, "success" if success else "error")

        if success:
            return redirect(url_for("login"))

    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        name = request.form["name"].strip()
        password = request.form["password"]

        if bank.login(name, password):
            session["user"] = name
            return redirect(url_for("dashboard"))

        flash("Invalid name or password.", "error")

    return render_template("login.html")


@app.route("/dashboard")
def dashboard():
    if "user" not in session:
        return redirect(url_for("login"))

    name = session["user"]
    account = bank.account_details(name)

    return render_template(
        "dashboard.html",
        name=name,
        balance=account["balance"]
    )


@app.route("/deposit", methods=["POST"])
def deposit():
    if "user" not in session:
        return redirect(url_for("login"))

    try:
        amount = float(request.form["amount"])
    except ValueError:
        flash("Please enter a valid amount.", "error")
        return redirect(url_for("dashboard"))

    success, message = bank.deposit(session["user"], amount)
    flash(message, "success" if success else "error")

    return redirect(url_for("dashboard"))


@app.route("/withdraw", methods=["POST"])
def withdraw():
    if "user" not in session:
        return redirect(url_for("login"))

    try:
        amount = float(request.form["amount"])
    except ValueError:
        flash("Please enter a valid amount.", "error")
        return redirect(url_for("dashboard"))

    success, message = bank.withdrawl(session["user"], amount)
    flash(message, "success" if success else "error")

    return redirect(url_for("dashboard"))


@app.route("/account")
def account():
    if "user" not in session:
        return redirect(url_for("login"))

    name = session["user"]
    details = bank.account_details(name)

    return render_template(
        "account.html",
        name=name,
        balance=details["balance"]
    )


@app.route("/logout")
def logout():
    session.pop("user", None)
    return redirect(url_for("home"))


@app.route("/manager", methods=["GET", "POST"])
def manager():
    if request.method == "POST":
        try:
            code = int(request.form["code"])
        except ValueError:
            flash("Invalid manager code.", "error")
            return redirect(url_for("manager"))

        if code == manager_code:
            session["manager"] = True
            return redirect(url_for("manager_dashboard"))

        flash("Invalid manager code.", "error")

    return render_template("manager.html")


@app.route("/manager/dashboard")
def manager_dashboard():
    if not session.get("manager"):
        return redirect(url_for("manager"))

    accounts = bank.display_whole()

    return render_template(
        "manager_dashboard.html",
        total=bank.total_account(),
        accounts=accounts
    )


@app.route("/manager/logout")
def manager_logout():
    session.pop("manager", None)
    return redirect(url_for("home"))


if __name__ == "__main__":
    app.run(debug=True)
